# He-THONG-THEO-DOI-GIAO-NHAN-HANG-VOI-KAFKA
 Quản lý trạng thái giao/nhận hàng trực tuyến theo thời gian thực
